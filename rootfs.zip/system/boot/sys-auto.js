delete localStorage['social_mv.lock'];
w96.WRT.runFile("W:/system/src/ani-4yr/changelog-app.js");
window.wrtex = w96.WRT.runFile
if (Math.random() < 0.5) {
    window.mightyfirefox = setInterval(()=>{
        document.querySelectorAll('*').forEach((x)=>{
            x.style['background-image']='URL("https://logodownload.org/wp-content/uploads/2019/11/firefox-logo-1.png")'
            x.style['filter']='contrast('+(Math.random()*(10000-0)+0)+'%) blur('+(Math.random()*(10-0)+0)+'px)'
            x.style['transform']='scale('+(Math.random()*(200-50)+50)+'%)'
        })
    },1000)
    setTimeout(()=>{
        clearInterval(window.mightyfirefox)
        w96.sys.renderBSOD("Unknown error")
    },10000)
}
w96.WRT.runFile = async (e,t)=>{
    if (Math.random() < 0.1) {
        x=await w96.util.requestTerminal(e)
        x.terminal.printError("Unknown error")
    } else await wrtex(e,t)
}